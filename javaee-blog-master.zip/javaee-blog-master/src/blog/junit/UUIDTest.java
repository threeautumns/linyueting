package blog.junit;

import java.util.UUID;

import org.junit.Test;

public class UUIDTest {

	@Test
	public void testUUID() {
		System.out.println(UUID.randomUUID());
	}

}
